# Dead Signal Weapon Progression Investigation

Target: **Blueprint Stars × Gear Tier I–V → displayed weapon stats**

Generated: `2026-08-14T16:10:01.936352+00:00`

## Current verdict

**displayed-intrinsic-star-tier-formula-proven-int-truncate**

- Tier I-V attack is available directly per weapon from gun_preset_attack; a universal Tier formula is therefore optional rather than required for Dead Signal.
- Every captured gun_blueprint_attr_data tuple level exactly matches its source strength_lv field; combined with rarity-dependent caps and the separate five-level forge Tier path, this strongly identifies the progression axis used for Blueprint enhancement/stars.
- Every captured strength row exposes preset_attack_radio. Its values are direct Attack multipliers (for example 1.05 = x1.05), so the Star-side Attack factor is mined per blueprint instead of inferred from a generic rarity formula.
- Blueprint-star effects are not Attack-only: progression modes in this snapshot are attack-ratio=82, no-changing-attack-ratio-or-skill-level=25, skill-level=13.
- Star x Tier matrices now multiply Tier gun_preset_attack directly by preset_attack_radio; the previous incorrect 1+ratio interpretation has been removed.
- The remapped client bytecode tail is now recognized directly: progression consumers return `preset_attack * attack_radio`. BINARY_OP argument 5 is multiply; no rounding call exists inside those recognized return tails.
- get_gun_preset_attack_radio returns the mined attack_ratio local directly before the multiplication consumer uses it.
- The remapped get_gun_attr_property_value branch for `weapon_omg_affix_value` is recognized directly and returns `get_gun_omg_value(gun_no, star)` with no intermediate numeric conversion.
- The displayed base-Attack builder get_weapon_base_attr_new is recognized wrapping that weapon-OMG property result in `int(...)` before storing `weapon_omg`. For positive weapon Attack, Python int() is truncate-toward-zero, which is equivalent to floor.
- The downstream D0100 display/stat chain is now focus-scanned in 12 captured function instances; stock disassembly is treated as diagnostic whenever the proven Once Human opcode-remapping profile is present.
- 6 D0100/display focus functions contain trustworthy rounding/format metadata and are priority final-display candidates.
- Static PYC scanning found 2096 non-table modules containing progression operands or chain symbols; 3791 caller functions were captured for downstream tracing.
- 474 progression-chain caller functions contain int/round/floor/ceil/trunc/format/str names in co_names and are priority rounding/display candidates.
- Calibration Blueprint Attack bonuses remain excluded from intrinsic Blueprint Star x Gear Tier progression.

## Tier I–V evidence

| Tier | n | median ratio to T1 | MAD | compatible rounding-factor interval(s) |
|---:|---:|---:|---:|---|
| 1 | 120 | 1 | 0 | nearest: 0.9984177215..1.001582278; floor: 1..1.003164557; ceil: 0.996835443..1 |
| 2 | 120 | 1.538461538 | 0.004511 | none |
| 3 | 120 | 2.458333333 | 0.009987 | none |
| 4 | 120 | 3.840833333 | 0.01613 | none |
| 5 | 120 | 5.839354839 | 0.02117 | none |

## Raw blueprint-level evidence

- **Common:** 32 weapons; common max raw level `3`; distribution `{3: 32}`
- **Epic:** 26 weapons; common max raw level `5`; distribution `{5: 26}`
- **Legendary:** 36 weapons; common max raw level `6`; distribution `{6: 36}`
- **Rare:** 26 weapons; common max raw level `4`; distribution `{3: 1, 4: 25}`

## Direct Star Attack factor

- Source field: `preset_attack_radio`
- Rows: **545**
- Coverage of strength rows: **100.0%**
- Semantics: direct multiplier (1.05 means x1.05), not additive bonus
- Progression effect modes: `{'attack-ratio': 82, 'no-changing-attack-ratio-or-skill-level': 25, 'skill-level': 13}`

Most common curves:
- **Common** × 22: `[1.0, 1.0, 1.0]`
- **Common** × 6: `[1.0, 1.0625, 1.125]`
- **Common** × 4: `[1.0, 1.0715, 1.143]`
- **Epic** × 23: `[1.0, 1.05575, 1.1115, 1.16725, 1.223]`
- **Epic** × 3: `[1.0, 1.0, 1.0, 1.0, 1.0]`
- **Legendary** × 32: `[1.0, 1.05, 1.1, 1.15, 1.2, 1.25]`
- **Legendary** × 4: `[1.0, 1.0, 1.0, 1.0, 1.0, 1.0]`
- **Rare** × 17: `[1.0, 1.06266666667, 1.12533333333, 1.188]`
- **Rare** × 8: `[1.0, 1.0, 1.0, 1.0]`
- **Rare** × 1: `[1.0, 1.0, 1.0]`

## Other Attack/Damage-like blueprint attributes

- `E0200` — Crit DMG
- `E0300` — Weakspot DMG

## PYC consumer hunt

- Persisted symbol indexes: **True**
- Live PYC roots available: **True**
- PYC files scanned: **94165**
- Non-table consumer candidates: **2096**
- Arithmetic/rounding candidates: **109**
- Focus functions captured: **108**
- Progression focus functions: **5**
- D0100/display focus functions: **12**
- D0100/display focus functions with rounding/format metadata: **5**
- Focus functions requiring raw-code fallback: **93**
- Progression-chain caller functions captured: **3791**
- Callers with rounding/format names in metadata: **474**

Focus consumer functions:
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.adjust_affix_val` — display — raw-code capsule — targets [] — decoded tail `val`
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.convert_affix_format_str` — display — raw-code capsule — targets [] — integer formats ['{:.0f}'] — decoded tail `format_val`
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_desc_format` — display — full disassembly — targets []
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_format_name_and_val` — display — raw-code capsule — targets [] — round/format names ['format', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_name_and_val` — display — raw-code capsule — targets [] — round/format names ['format', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_name_and_val2` — display — raw-code capsule — targets [] — round/format names ['format', 'int', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_format_attr_val` — display — raw-code capsule — targets [] — round/format names ['int', 'round'] — decoded tail `val`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_gun_omg_value` — progression — raw-code capsule — targets ['gun_blueprint_attr_data', 'gun_preset_attack', 'preset_attack_radio'] — decoded tail `preset_attack * attack_radio`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_gun_preset_attack_radio` — progression — raw-code capsule — targets ['gun_blueprint_attr_data', 'preset_attack_radio'] — decoded tail `attack_radio`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_gun_shoot_attr_weapon_rpm` — weapon_aggregator — raw-code capsule — targets [] — round/format names ['round']
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_gun_shoot_interval` — weapon_aggregator — raw-code capsule — targets []
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_init_weapon_stability` — weapon_aggregator — full disassembly — targets [] — decoded tail `init_weapon_stability`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_reload_add_bullet_time_value` — weapon_aggregator — raw-code capsule — targets []
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_weapon_accuracy_rate` — weapon_aggregator — raw-code capsule — targets [] — decoded tail `mean_deg_rate`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_weapon_stability_affix` — weapon_aggregator — full disassembly — targets [] — decoded tail `weapon_stability_affix`
- `dcs_extend/common/shoot_utility.pyc` :: `<module>.get_weapoon_range_value` — weapon_aggregator — raw-code capsule — targets []
- `dcs_extend/const/attr_const.pyc` :: `<module>` — display_constants — raw-code capsule — targets []
- `game_common/build/StorageFacility.pyc` :: `<module>.ClientStorageBagPart.get_item_calibration_attr` — calibration — raw-code capsule — targets []
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>._rand_term_no_lst` — calibration — raw-code capsule — targets []
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>.gen_rand_correct_affixs` — calibration — full disassembly — targets []
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>.gen_rand_gun_affixs` — calibration — raw-code capsule — targets []
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>.get_max_term_affix_value` — calibration — raw-code capsule — targets [] — decoded tail `max_affix_val`
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>.rand_term_affix_data` — calibration — raw-code capsule — targets []
- `game_common/guncore/GunAccessoryHelper.pyc` :: `<module>.get_gun_accessory_list` — weapon_aggregator — raw-code capsule — targets []
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.construct_correct_blueprint_term_info_by_affix_list` — calibration — raw-code capsule — targets []
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.convert_data_adjust_show_attr` — display — raw-code capsule — targets []
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.convert_data_show_attr` — display — raw-code capsule — targets []
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.generate_correct_print_term_id` — calibration — raw-code capsule — targets []
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.generate_correct_term_data` — calibration — raw-code capsule — targets [] — round/format names ['round']
- `game_common/guncore/GunCoreHelper.pyc` :: `<module>.generate_gun_correct_print_detail` — calibration — raw-code capsule — targets []

Progression-chain callers with rounding/format metadata:
- `game_common/Mod/ModDataHelper.pyc` :: `<module>.get_entry_desc` — calls ['get_affix_desc_format'] — names ['float', 'format', 'int', 'round', 'str']
- `ui/PanelSeasonPassBuyLevel.pyc` :: `<module>.PanelSeasonPassBuyLevelBase.on_slider_value_changed` — calls ['refresh_item_lst'] — names ['format', 'int', 'round', 'str']
- `ui/PanelWishDetailLog.pyc` :: `<module>.WishDetailScrollPart.set_normal_prize` — calls ['refresh_item_lst'] — names ['format', 'int', 'round', 'str']
- `ui/private_server_setting_part/gm_adjust_sub_item.pyc` :: `<module>.PrivateServerSettingGmAdjustSubItemBase.after_init_ui_node` — calls ['refresh_item_lst'] — names ['float', 'format', 'int', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_name_and_val2` — calls ['adjust_affix_val', 'convert_affix_format_str'] — names ['format', 'int', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_desc_with_name_and_val` — calls ['adjust_affix_val', 'convert_affix_format_str'] — names ['format', 'int', 'str']
- `ui/PanelNeverlandUGCPlayDetail.pyc` :: `<module>.PanelNeverlandUGCPlayDetailBase.refresh_mini_btn` — calls ['refresh_item_lst'] — names ['int', 'round', 'str']
- `ui/PanelNeverlandUGCRoom.pyc` :: `<module>.PanelNeverlandUGCRoomBase.init_room` — calls ['refresh_item_lst'] — names ['ceil', 'int', 'str']
- `ui/PanelPrivateServerDetail.pyc` :: `<module>.PanelPrivateServerDetailBase._detail_refresh_hot_tags` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/PanelRiftChallenge.pyc` :: `<module>.NodeRiftRightPopBase._refresh_lv_score_tags` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/PanelSeasonPopTeamIdSearch.pyc` :: `<module>.PanelSeasonPopTeamIdSearchBase.render_page` — calls ['refresh_item_lst'] — names ['ceil', 'float', 'int']
- `ui/activity_part/activity2604/milestone/ActivitySeasonMilestoneS4.pyc` :: `<module>.ActivitySeasonMilestoneS4Base.refresh_season_special_panel` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/activity_part/node/NodeCalendarCardItem.pyc` :: `<module>.NodeCalendarCardItemBase.refresh_ui` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/bounty_hunter_part/UIBountyHunterStatuePart.pyc` :: `<module>.UIBountyHunterStatueBase.update_info` — calls ['refresh_item_lst'] — names ['ceil', 'format', 'str']
- `ui/data_tools/ItemDataTools.pyc` :: `<module>.get_gun_base_random_attr` — calls ['get_affix_name_and_val', 'get_format_attr_val'] — names ['format', 'int', 'round']
- `ui/meme_part/MemeticRewardInfoPart.pyc` :: `<module>.MemeticLevelRewardInfoBase.refresh_level_reward_info` — calls ['refresh_item_lst'] — names ['float', 'format', 'str']
- `ui/new_produce_part/UIPortableKitchenOrderPart.pyc` :: `<module>.UIPortableKitchenOrderPartBase._do_refresh_order_list` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/private_server_login_v2/PrivateServerCardItem.pyc` :: `<module>.PrivateServerCardItemBase._refresh_right_top_tag` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/resource_part/UIResourceProduceItem.pyc` :: `<module>.UIResourceProduceItemBase.show_upgrade_part` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/season_review/SeasonReviewInfoPart.pyc` :: `<module>.SeasonReviewInfoPartBase.get_tab_ui_infos` — calls ['refresh_item_lst'] — names ['ceil', 'float', 'int']
- `ui/shop/NpcShopItemsCbt2.pyc` :: `<module>.ShopLongItemBase.update_info` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `ui/warband/SourceBossBattleScoreDetailPart.pyc` :: `<module>.SourceBossBattleProcessDetailBase.update_info` — calls ['refresh_item_lst'] — names ['format', 'int', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_format_name_and_val` — calls ['adjust_affix_val', 'convert_affix_format_str'] — names ['format', 'str']
- `dcs_extend/common/affix/AffixUtils.pyc` :: `<module>.get_affix_name_and_val` — calls ['adjust_affix_val', 'convert_affix_format_str'] — names ['format', 'str']
- `game_common/guncore/BluePrintHelper.pyc` :: `<module>.get_blueprint_star_attr` — calls ['get_affix_name_and_val'] — names ['int', 'str']
- `ui/PanelActivityInheritConvenePop.pyc` :: `<module>.PanelActivityInheritConvenePopBase.init_frined_list` — calls ['refresh_item_lst'] — names ['ceil', 'format']
- `ui/PanelActivityRankReward.pyc` :: `<module>.PanelActivityRankRewardItem.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelActivityRedEnvelopePop.pyc` :: `<module>.NodeRedEnvelopItemBase.init_ui` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelBattleReportDetail.pyc` :: `<module>.PanelBattleReportDetailBase.update_detail_info` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelBedReviveOutRange.pyc` :: `<module>.PanelBedReviveOutRangeBase.on_loaded` — calls ['refresh_item_lst'] — names ['round', 'str']
- `ui/PanelBigMapItemDetail.pyc` :: `<module>.PublicUIStyle._init_ui_common` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelBigMapLighthouseDetail.pyc` :: `<module>.PanelBigMapLighthouseDetailBase.refresh_state` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelBigMapPublicTemperatureTowerTips.pyc` :: `<module>.PanelBigMapPublicTemperatureTowerTipsBase.refresh_info` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelBigMapTowerFloorDetail.pyc` :: `<module>.PanelTowerFloorDetailBase._init_ui` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelBigMapTowerFloorDetail.pyc` :: `<module>.PanelTowerFloorDetailBase._refresh_on_mode_switch` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelBlackPlainRank.pyc` :: `<module>.BlackPlainRankCampRewardPartBase.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelCreateTeamPopUI.pyc` :: `<module>.PanelCreateTeamPopUIBase.init_ui_node` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelDeviationRankAwardPreview.pyc` :: `<module>.PanelDeviationRankAwardPreview.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelFirstSetting.pyc` :: `<module>.SetHDRLightPart.refresh_param_list` — calls ['refresh_item_lst'] — names ['float', 'int']
- `ui/PanelFurnitureBlindBox.pyc` :: `<module>.PanelFurnitureBlindBoxBase.update_total_num` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelJourneyMayFlyPopUI.pyc` :: `<module>.JourneyMayflyTaskPopUIBase.on_loaded` — calls ['refresh_item_lst'] — names ['int', 'str']
- `ui/PanelLuckyDrawRightPop.pyc` :: `<module>.PanelLuckyDrawRightPopBase.init_ui` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelNeverlandUGCCoinRankPop.pyc` :: `<module>.PanelNeverlandUGCCoinRankPopBase.refresh_rank_data` — calls ['refresh_item_lst'] — names ['int', 'str']
- `ui/PanelNeverlandUGCCoinTipsPop.pyc` :: `<module>.PanelNeverlandUGCCoinTipsPopBase.init_ui_node` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelPalWorldWorkRankAwardPreview.pyc` :: `<module>.PanelPalWorldWorkRankRewardItem.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelPlantBox.pyc` :: `<module>.PanelPlantBoxBase.update_buff_info` — calls ['refresh_item_lst'] — names ['int', 'round']
- `ui/PanelPlantBoxCombatMining.pyc` :: `<module>.NodeProgressItemPartBase.update_info` — calls ['refresh_item_lst'] — names ['format', 'round']
- `ui/PanelPrivateExchange.pyc` :: `<module>.PanelPrivateExchangeBase.refresh_goods_item` — calls ['refresh_item_lst'] — names ['int', 'round']
- `ui/PanelPrivateRankAwardPreview.pyc` :: `<module>.PanelPrivateRankRewardItem.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelPrivateServerDetail.pyc` :: `<module>.PanelPrivateServerDetailBase._detail_refresh` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelPublicTemperatureTowerActivate.pyc` :: `<module>.PublicTemperatureTowerEffectPartBase.refresh_info` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelPublicTemperatureTowerMain.pyc` :: `<module>.PublicTemperatureTowerBossInfoPartBase.refresh_info` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelPveInteractEntranceV3.pyc` :: `<module>.PanelPveInteractEntranceV3Base.on_select_entry_id_change` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelRaceEnding.pyc` :: `<module>.PanelRaceEndingBase.on_loaded` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelRiftChallenge.pyc` :: `<module>.NodeRiftRightPopBase._init_help_items` — calls ['refresh_item_lst'] — names ['int', 'str']
- `ui/PanelRustNiShaDevice.pyc` :: `<module>.NiShaDeviceLevelPartBase.refresh_lv_part` — calls ['refresh_item_lst'] — names ['format', 'int']
- `ui/PanelSeasonPersonalReward.pyc` :: `<module>.SeasonPersonalRewardItemBase.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelSetHDRLight.pyc` :: `<module>.PanelSetHDRLight.refresh_param_list` — calls ['refresh_item_lst'] — names ['float', 'int']
- `ui/PanelShortCutPopMobile.pyc` :: `<module>.PanelShortCutPopMobileBase.update_shortcut_panel` — calls ['refresh_item_lst'] — names ['format', 'str']
- `ui/PanelSpeedActivityRewardPop.pyc` :: `<module>.PanelSpeedActivityRewardPopItem.update_info` — calls ['refresh_item_lst'] — names ['format', 'str']

Top PYC candidates:
- `ui/data_tools/ItemDataTools.pyc` — score 2580 — consumer-candidate — ['preset_attack_radio', 'strength_lv', 'gun_preset_attack', 'gun_blueprint_attr_data', 'D0100', 'gun_correct_affix_val', 'gun_correct_affix_list', 'gun_correct_print_data', 'gun_correct_common_terms_data', 'gun_calibration_affix_option_data', 'D0101', 'D0102', 'correct_style', 'gun_correct_item_no', 'gun_calibration_attr', 'correct_affix_add', 'affix_options', 'affix_option_libs', 'VM_GUN_FORMULAS', 'all_affix_adds', 'all_calc_affix_add', 'base_affix_add', 'accessory_affix_add', 'rand_affix_add', 'affix_option_add', 'cal_affix', 'all_guncore_affix_add', 'all_guncore_affix_primitive', 'accessory_affix_primitive', 'accessory_calc_affix_add', 'gun_slot_accessory_data_list', 'item_attack_base', 'item_attack_guncore', 'item_attack', 'attack_radio', 'delta_attack', 'attr_radio_affix_ids', 'affix_prototype_data', 'Q0800', 'Q0900', 'Q1100', '_calc_gun_attr_list', 'cal_gun_attr_data_with_item_no', 'calc_gun_attr_data', 'convert_data_show_attr', 'convert_gun_correct_affix_val_to_affix_list', 'gen_rand_gun_affixs', 'get_affix_name_and_val', 'get_affix_name_and_val2', 'get_all_guncore_affix_add', 'get_blueprint_affix_add', 'get_equipped_accessorys', 'get_format_attr_val', 'get_gun_accessory_affix_add', 'get_gun_accessory_all_show_list_data', 'get_gun_accessory_all_show_slot_pos', 'get_gun_accessory_list', 'get_gun_affix_add', 'get_gun_affix_option_add', 'get_gun_attack', 'get_gun_attack_base', 'get_gun_attack_guncore', 'get_gun_base_affix_add', 'get_gun_base_affix_attack', 'get_gun_base_random_attr', 'get_gun_base_random_attr_list', 'get_gun_calc_accessory_affix_add', 'get_gun_calc_affix_add', 'get_gun_calibration_attr', 'get_gun_correct_affix_add', 'get_gun_correct_item_no', 'get_gun_info', 'get_gun_magazine_affix_add', 'get_gun_magazine_size', 'get_gun_mobility', 'get_gun_no_rand_affix_add', 'get_gun_rand_attr', 'get_gun_rand_attr_affix_add', 'get_gun_rpm_val', 'get_gun_shoot_attr_weapon_rpm', 'get_gun_slot_accessory_data_list', 'get_item_calibration_attr', 'get_weapon_base_attr_list', 'get_weapon_base_attr_new']
- `game_common/guncore/GunCoreHelper.pyc` — score 1240 — consumer-candidate — ['strength_lv', 'gun_blueprint_attr_data', 'D0100', 'affix_val_range', 'affix_ids_weight', 'gun_correct_affix_val', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'gun_correct_common_terms_data', 'gun_calibration_affix_option_data', 'correct_style', 'calibration_style_gun', 'calibration_option_gun', 'affix_option_libs', 'affix_prototype_data', 'ATTR_VAL_ABS', 'val_type', 'format_val_str', 'construct_correct_blueprint_term_info_by_affix_list', 'convert_data_adjust_show_attr', 'convert_data_show_attr', 'generate_correct_print_term_id', 'generate_correct_term_data', 'generate_gun_correct_print_detail', 'generate_gun_correct_print_info', 'get_affix_name_and_val', 'get_affix_name_and_val2', 'get_gun_calibration_affix_option_libs', 'get_gun_calibration_affix_option_size', 'get_gun_correct_affix_desc', 'get_gun_omg_value', 'get_init_weapon_stability', 'get_max_term_affix_value', 'get_weapon_base_attr_dict', 'get_weapon_base_attr_list', 'get_weapon_base_attr_new', 'init_gun_correct_print_info', 'rand_term_affix_data']
- `ui/data_model/UIGunAdjustAttr.pyc` — score 615 — consumer-candidate — ['strength_lv', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_blueprint_terms_pool', 'calibration_style_gun', 'calibration_option_gun', 'gun_correct_item_no', 'gun_calibration_attr', 'affix_options', 'affix_option_libs', 'all_calc_affix_add', 'base_affix_add', 'accessory_affix_add', 'rand_affix_add', 'affix_option_add', 'calc_gun_attr_data', 'get_format_attr_val', 'get_gun_affix_add', 'get_gun_base_random_attr', 'get_gun_base_random_attr_data', 'get_gun_calibration_affix_option_libs', 'get_gun_calibration_attr', 'get_gun_info', 'rand_term_affix_data']
- `dcs_extend/common/shoot_utility.pyc` — score 565 — consumer-candidate — ['preset_attack_radio', 'gun_preset_attack', 'gun_blueprint_attr_data', 'attack_radio', 'get_gun_omg_value', 'get_gun_preset_attack_radio', 'get_gun_shoot_attr_weapon_rpm', 'get_gun_shoot_interval', 'get_init_weapon_stability', 'get_reload_add_bullet_time_value', 'get_weapon_accuracy_rate', 'get_weapon_stability_affix', 'get_weapoon_range_value']
- `ui/data_model/UIAccessoryDataModel.pyc` — score 535 — consumer-candidate — ['D0100', 'D0101', 'all_calc_affix_add', 'accessory_affix_add', 'cal_affix', 'item_attack_base', 'item_attack_guncore', 'item_attack', 'Q0100', 'Q0300', 'Q0500', 'Q1100', 'Q1600', 'Q2400', 'get_affix_name_and_val', 'get_format_attr_val', 'get_gun_base_random_attr', 'get_gun_base_random_attr_data', 'get_reload_add_bullet_time_value', 'get_weapon_accuracy_rate', 'get_weapoon_range_value']
- `game_common/guncore/BluePrintHelper.pyc` — score 490 — consumer-candidate — ['strength_lv', 'gun_blueprint_attr_data', 'gun_blueprint_terms_pool', 'GUN_BLUEPRINT_TERMS_POOL', 'calibration_style_gun', 'calibration_option_gun', '_rand_term_no_lst', 'gen_rand_correct_affixs', 'gen_rand_gun_affixs', 'generate_correct_term_data', 'generate_gun_correct_print_info', 'get_affix_name_and_val', 'get_format_attr_val', 'get_max_term_affix_value', 'rand_term_affix_data']
- `dcs_extend/common/affix/AffixUtils.pyc` — score 470 — consumer-candidate — ['affix_prototype_data', 'AP_CALC_TYPE_ABS', 'AP_CALC_TYPE_RATE', 'ATTR_VAL_ABS', 'ATTR_VAL_RATE', 'effect_range', 'val_type', 'format_val_str', 'adjust_affix_val', 'convert_affix_format_str', 'get_affix_desc_format', 'get_affix_format_name_and_val', 'get_affix_name_and_val', 'get_affix_name_and_val2', 'get_format_attr_val']
- `game_common/item/ItemHelper.pyc` — score 450 — consumer-candidate — ['D0100', 'affix_val_range', 'gun_correct_affix_val', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'D0102', 'correct_style', 'item_attack', 'val_type', 'construct_correct_blueprint_term_info_by_affix_list']
- `ui/weapon_craft_part/pc/WeaponMakeRightPartPC.pyc` — score 445 — consumer-candidate — ['gun_correct_affix_val', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'correct_style', 'calc_gun_attr_data', 'convert_gun_correct_affix_val_to_affix_list', 'get_gun_info', 'refresh_base_prop', 'refresh_item_lst']
- `game_common/item/EquipHelper.pyc` — score 430 — consumer-candidate — ['preset_attack_radio', 'strength_lv', 'gun_preset_attack', 'D0102', 'attack_radio', 'affix_prototype_data', 'AP_CALC_TYPE_ABS', 'ATTR_VAL_ABS', 'val_type', 'get_affix_name_and_val', 'get_format_attr_val', 'get_gun_accessory_list', 'get_gun_average_tire', 'get_gun_preset_attack_radio']
- `ui/common_ui/CommonTipsUI.pyc` — score 425 — consumer-candidate — ['strength_lv', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'gun_correct_common_terms_data', 'correct_style', 'calibration_style_gun', 'calibration_option_gun', 'gun_correct_item_no', 'format_val_str', 'get_affix_name_and_val', 'get_affix_name_and_val2', 'get_gun_info', 'refresh_item_lst']
- `ui/equip_craft_part/GunAdjustPartItem.pyc` — score 340 — consumer-candidate — ['strength_lv', 'gun_correct_print_data', 'gun_correct_common_terms_data', 'correct_style', 'calibration_style_gun', 'calibration_option_gun', 'format_val_str', 'get_affix_name_and_val', 'get_affix_name_and_val2', 'refresh_item_lst']
- `ui/equip_part/tips_part/TipsPartEquipCorrectItemOverview.pyc` — score 315 — consumer-candidate — ['affix_val_range', 'gun_correct_affix_val', 'gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'D0102', 'correct_style', 'construct_correct_blueprint_term_info_by_affix_list', 'get_item_calibration_attr', 'refresh_item_lst']
- `dcs_extend/const/attr_const.pyc` — score 295 — consumer-candidate — ['affix_prototype_data', 'AP_CALC_TYPE_ABS', 'AP_CALC_TYPE_RATE', 'ATTR_VAL_ABS', 'ATTR_VAL_RATE', 'Q1100']
- `ui/data_model/UIOnlineTradeData.pyc` — score 285 — consumer-candidate — ['gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_print_data', 'gun_correct_common_terms_data', 'correct_style', 'calibration_style_gun', 'format_val_str', 'get_affix_name_and_val', 'get_affix_name_and_val2']
- `ui/PanelAccessoryTipsPC.pyc` — score 275 — consumer-candidate — ['D0100', 'D0101', 'gun_correct_item_no', 'item_attack_base', 'item_attack_guncore', 'item_attack', 'get_affix_name_and_val', 'get_gun_info']
- `ui/gun_core_part/GunPackAbilityPart.pyc` — score 250 — consumer-candidate — ['gun_correct_affix_list', 'gun_correct_print_data', 'gun_correct_item_no', 'gun_calibration_attr', 'refresh_item_lst']
- `game_common/data/affix_prototype_data.pyc` — score 240 — consumer-candidate — ['D0100', 'D0101', 'D0102', 'affix_prototype_data', 'effect_range', 'Q0100', 'Q0300', 'Q0500', 'Q0800', 'Q0900', 'Q1100', 'Q1101', 'Q1600', 'Q2000', 'Q2400', 'Q2600']
- `ui/data_model/UIEquipmentData.pyc` — score 234 — consumer-candidate — ['VM_GUN_FORMULAS', 'all_calc_affix_add', 'gun_slot_accessory_data_list', 'affix_prototype_data', 'convert_affix_format_str', 'get_affix_format_name_and_val', 'get_gun_info', 'get_gun_slot_accessory_data_list', 'get_init_weapon_stability', 'get_weapon_stability_affix']
- `ui/data_model/UIEquipAdjustAttr.pyc` — score 225 — consumer-candidate — ['strength_lv', 'gun_blueprint_terms_pool', 'all_calc_affix_add', 'get_format_attr_val', 'get_gun_base_random_attr', 'get_gun_base_random_attr_data', 'rand_term_affix_data']
- `game_common/guncore/MeleeHandler.pyc` — score 220 — consumer-candidate — ['gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_item_no', 'gen_rand_correct_affixs', 'gen_rand_gun_affixs']
- `game_common/guncore/GunCoreHandler.pyc` — score 210 — consumer-candidate — ['gun_correct_affix_list', 'gun_correct_affix_skill', 'gun_correct_item_no', 'gen_rand_correct_affixs', 'gen_rand_gun_affixs']
- `ui/equip_part/equipconst.pyc` — score 210 — consumer-candidate — ['D0100', 'D0101', 'D0102', 'Q0100', 'Q0300', 'Q0500', 'Q0800', 'Q1100', 'Q1101']
- `game_common/item/DropRuleHelper.pyc` — score 180 — consumer-candidate — ['strength_lv', 'gen_rand_correct_affixs', 'gen_rand_gun_affixs', 'get_format_attr_val', 'rand_term_affix_data']
- `game_common/guncore/GunAccessoryHelper.pyc` — score 170 — consumer-candidate — ['D0100', 'Q0800', 'Q1100', 'get_affix_name_and_val', 'get_gun_accessory_list', 'get_gun_info']

## Source hunt

- Relevant raw tables scanned: **2123**
- Relevant raw rows scanned: **165158**
- Candidate records found: **18064**

Highest-value tables:
- `game_common/data/equip_data.json` — 7562 candidate rows
- `game_common/data/equip_origin_data.json` — 5042 candidate rows
- `game_common/data/blueprint_art_to_equip_map.json` — 1191 candidate rows
- `game_common/data/equip_blueprint_attr_data.json` — 1135 candidate rows
- `game_common/data/gun_blueprint_attr_data.json` — 1091 candidate rows
- `game_common/data/gun_blueprint_terms_map_data.json` — 702 candidate rows
- `game_common/data/gun_blueprint_data.json` — 383 candidate rows
- `game_common/data/close_weapon_data.json` — 361 candidate rows
- `game_common/data/gun_base_params_data.json` — 340 candidate rows
- `game_common/data/blueprint_recipe_season_data.json` — 120 candidate rows
- `game_common/data/damage_and_attribute_monitor_data.json` — 39 candidate rows
- `game_common/data/gun_range_formula_template_data.json` — 19 candidate rows
- `game_common/data/equip_make_strengthen_rule.json` — 9 candidate rows
- `game_common/data/nuclear_level_data.json` — 5 candidate rows
- `game_common/data/rust_area_level_data.json` — 5 candidate rows
- `game_common/data/logic_tree/behavior_gravitation_attract_tree_trap_1.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_gravitation_attract_tree_trap_2.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_kxm_skill1_missile_level3_missile_1.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_kxm_skill1_missile_level3_missile_2.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_manned_turret_1_fire_elite_shotgun_cannon_Fire.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_manned_turret_1_fire_shotgun_cannon_Fire.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_manned_turret_1_fire_triple_shot_shotgun_cannon_Fire.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_manned_turret_1_level_turret_1_throw.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_manned_turret_1_level_turret_2_throw.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_mob_shotgun_phlogiston_pvp_shoot.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_mob_shotgun_phlogiston_shoot.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_mob_snipe_s1_gun_light.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_mob_snipe_s1_gun_shoot.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_m_spider_spider_rongzhu_lava_machinegun_building_shoot.json` — 1 candidate rows
- `game_common/data/logic_tree/behavior_m_spider_spider_rongzhu_lava_machinegun_building_trap.json` — 1 candidate rows

## Rule before shipping calculator math

The intrinsic positive-Attack display path is proven as int(Tier gun_preset_attack × preset_attack_radio[strength_lv]). Calibration Blueprint Attack rolls and later affix/mod/combat layers remain separate systems.
